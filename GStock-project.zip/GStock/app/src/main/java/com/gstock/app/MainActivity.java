package com.gstock.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;

public class MainActivity extends Activity {
    StockDb db; LinearLayout root, list; EditText search; String lang="ar";
    static final int IMPORT_JSON=301;
    String tr(String ar,String fr,String en){return lang.equals("fr")?fr:(lang.equals("en")?en:ar);}
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new StockDb(this); showHome();}
    TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff172033);t.setPadding(0,8,0,8);return t;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
    void setup(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,18,20,16);root.setBackgroundColor(0xfff4f7fb);
        ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);
        TextView brand=label("G-STOCK  •  "+title,24);brand.setTypeface(null,Typeface.BOLD);brand.setTextColor(0xff1746a2);root.addView(brand);
        LinearLayout langs=new LinearLayout(this); langs.addView(button("العربية",()->{lang="ar";showHome();})); langs.addView(button("Français",()->{lang="fr";showHome();})); langs.addView(button("English",()->{lang="en";showHome();}));root.addView(langs);
    }
    void showHome(){
        setup(tr("لوحة التحكم","Tableau de bord","Dashboard"));
        TextView sub=label(tr("إدارة المخزون ببساطة","Gestion de stock simple","Simple inventory management"),16);root.addView(sub);
        root.addView(label(tr("المواد: ","Articles: ","Items: ")+db.countItems(),18));
        root.addView(label(tr("مواد وصلت للحد الأدنى: ","Articles au seuil minimum: ","Low-stock items: ")+db.lowStock(),18));
        root.addView(label(tr("إجمالي الكميات: ","Quantité totale: ","Total quantity: ")+db.totalQuantity(),18));
        root.addView(button(tr("＋ إضافة مادة","＋ Ajouter un article","＋ Add item"),this::addItem));
        root.addView(button(tr("📦 المخزون","📦 Stock","📦 Inventory"),()->showInventory("")));
        root.addView(button(tr("⇄ مشاركة / نسخ احتياطي","⇄ Partage / sauvegarde","⇄ Share / backup"),this::shareBackup));
        root.addView(button(tr("استيراد نسخة احتياطية","Importer une sauvegarde","Import backup"),this::chooseImport));
        root.addView(label(tr("مشاركة البيانات تتم عند طلبك فقط. أرسل النسخة إلى جهازين موثوقين كحد أقصى، ثم استوردها في G-Stock على كل جهاز. هذه نسخة يدوية وليست مزامنة مباشرة.","Le partage se fait uniquement à votre demande. Envoyez la sauvegarde à deux appareils de confiance au maximum, puis importez-la dans G-Stock. Il s’agit d’un transfert manuel, pas d’une synchronisation en direct.","Data is shared only when you choose. Send the backup to up to two trusted devices, then import it into G-Stock on each device. This is manual transfer, not live sync."),13));
    }
    void addItem(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        EditText name=new EditText(this);name.setHint(tr("اسم المادة *","Nom de l’article *","Item name *"));form.addView(name);
        EditText cat=new EditText(this);cat.setHint(tr("الفئة","Catégorie","Category"));form.addView(cat);
        EditText qty=new EditText(this);qty.setInputType(8194);qty.setHint(tr("الكمية","Quantité","Quantity"));form.addView(qty);
        EditText min=new EditText(this);min.setInputType(8194);min.setHint(tr("حد التنبيه","Seuil d’alerte","Low-stock threshold"));form.addView(min);
        EditText unit=new EditText(this);unit.setHint(tr("الوحدة (قطعة، علبة...)","Unité (pièce, boîte...)","Unit (piece, box...)"));form.addView(unit);
        EditText supplier=new EditText(this);supplier.setHint(tr("المورّد","Fournisseur","Supplier"));form.addView(supplier);
        new AlertDialog.Builder(this).setTitle(tr("إضافة مادة","Ajouter un article","Add item")).setView(form)
        .setPositiveButton(tr("حفظ","Enregistrer","Save"),(d,w)->{
            String n=name.getText().toString().trim(); if(n.isEmpty()){toast(tr("اسم المادة مطلوب","Le nom est obligatoire","Item name is required"));return;}
            try{double q=qty.getText().toString().trim().isEmpty()?0:Double.parseDouble(qty.getText().toString());double m=min.getText().toString().trim().isEmpty()?0:Double.parseDouble(min.getText().toString());if(q<0||m<0)throw new NumberFormatException();
                db.addItem(n,cat.getText().toString(),q,m,unit.getText().toString(),supplier.getText().toString());showHome();
            }catch(Exception e){toast(tr("أدخل كميات صحيحة غير سالبة","Saisissez des quantités valides et positives","Enter valid non-negative quantities"));}
        }).setNegativeButton(tr("إلغاء","Annuler","Cancel"),null).show();
    }
    void showInventory(String q){
        setup(tr("المخزون","Stock","Inventory"));
        search=new EditText(this);search.setSingleLine(true);search.setHint(tr("ابحث عن مادة أو فئة","Rechercher un article ou une catégorie","Search item or category"));search.setText(q);root.addView(search);
        root.addView(button(tr("بحث","Rechercher","Search"),()->showInventory(search.getText().toString())));
        root.addView(button(tr("＋ إضافة مادة","＋ Ajouter un article","＋ Add item"),this::addItem));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        Cursor c=db.allItems(q);
        while(c.moveToNext()){
            final long id=c.getLong(0); String name=c.getString(1),cat=c.getString(2);double qty=c.getDouble(3),min=c.getDouble(4);String unit=c.getString(5),sup=c.getString(6);
            TextView card=label(name+"  •  "+qty+" "+unit+"\n"+cat+"  |  "+tr("الحد الأدنى: ","Seuil: ","Minimum: ")+min+"\n"+tr("المورّد: ","Fournisseur: ","Supplier: ")+sup,16);
            card.setBackgroundColor(qty<=min?0xffffe9e7:0xffffffff);card.setPadding(14,14,14,14);list.addView(card);
            LinearLayout actions=new LinearLayout(this);actions.addView(button("+",()->adjust(id,1)));actions.addView(button("−",()->adjust(id,-1)));actions.addView(button(tr("إخراج","Sortie","Stock out"),()->adjust(id,-1)));list.addView(actions);
        }c.close();root.addView(button(tr("رجوع للرئيسية","Retour à l’accueil","Back to dashboard"),this::showHome));
    }
    void adjust(long id,int direction){
        EditText amount=new EditText(this);amount.setInputType(8194);amount.setHint(tr("الكمية","Quantité","Quantity"));
        new AlertDialog.Builder(this).setTitle(direction>0?tr("إدخال مخزون","Entrée de stock","Stock in"):tr("إخراج مخزون","Sortie de stock","Stock out")).setView(amount)
        .setPositiveButton(tr("تأكيد","Confirmer","Confirm"),(d,w)->{try{double x=Double.parseDouble(amount.getText().toString());if(x<=0)throw new Exception();boolean ok=db.changeQuantity(id,x*direction,"");if(!ok)toast(tr("الكمية غير كافية أو المادة غير موجودة","Quantité insuffisante ou article introuvable","Insufficient quantity or item missing"));showInventory("");}catch(Exception e){toast(tr("أدخل كمية صحيحة","Saisissez une quantité valide","Enter a valid quantity"));}}).setNegativeButton(tr("إلغاء","Annuler","Cancel"),null).show();
    }
    void shareBackup(){
        try{
            File f=new File(getCacheDir(),"GStock-backup.json");
            try(FileWriter w=new FileWriter(f)){w.write(db.exportJson().toString(2));}
            // Use ACTION_SEND with JSON text as a portable backup; share sheet lets the user choose the destination.
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"G-Stock backup");i.putExtra(Intent.EXTRA_TEXT,db.exportJson().toString());startActivity(Intent.createChooser(i,tr("مشاركة نسخة بيانات G-Stock","Partager la sauvegarde G-Stock","Share G-Stock backup")));
        }catch(Exception e){toast(tr("تعذر إنشاء النسخة الاحتياطية","Échec de création de la sauvegarde","Could not create backup"));}
    }
    void chooseImport(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT_JSON);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==IMPORT_JSON&&result==RESULT_OK&&data!=null){try(InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);db.importJson(new JSONObject(out.toString("UTF-8")));toast(tr("تم الاستيراد. راجع المواد لتجنب التكرار.","Import terminé. Vérifiez les doublons.","Import complete. Check for duplicates."));showHome();}catch(Exception e){toast(tr("ملف غير صالح أو تعذر قراءته","Fichier invalide ou illisible","Invalid or unreadable file"));}}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
