package com.gstock.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import org.json.*;

public class StockDb extends SQLiteOpenHelper {
    public StockDb(Context c) { super(c, "gstock.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT DEFAULT '', quantity REAL NOT NULL DEFAULT 0, min_quantity REAL NOT NULL DEFAULT 0, unit TEXT DEFAULT '', supplier TEXT DEFAULT '', updated_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER, type TEXT, quantity REAL, note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {}
    public Cursor allItems(String q) {
        return getReadableDatabase().rawQuery("SELECT id,name,category,quantity,min_quantity,unit,supplier FROM items WHERE name LIKE ? OR category LIKE ? ORDER BY name",
                new String[]{"%"+q+"%","%"+q+"%"});
    }
    public long addItem(String name,String category,double qty,double min,String unit,String supplier) {
        ContentValues v=new ContentValues(); v.put("name",name); v.put("category",category); v.put("quantity",qty); v.put("min_quantity",min); v.put("unit",unit); v.put("supplier",supplier);
        return getWritableDatabase().insert("items",null,v);
    }
    public boolean changeQuantity(long id,double delta,String note) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            Cursor c=db.rawQuery("SELECT quantity FROM items WHERE id=?",new String[]{String.valueOf(id)});
            if(!c.moveToFirst()){c.close();return false;}
            double old=c.getDouble(0); c.close(); double now=old+delta; if(now<0)return false;
            ContentValues v=new ContentValues(); v.put("quantity",now); v.put("updated_at",new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date()));
            db.update("items",v,"id=?",new String[]{String.valueOf(id)});
            ContentValues m=new ContentValues(); m.put("item_id",id); m.put("type",delta>=0?"IN":"OUT"); m.put("quantity",Math.abs(delta)); m.put("note",note);
            db.insert("movements",null,m); db.setTransactionSuccessful(); return true;
        } finally { db.endTransaction(); }
    }
    public int countItems(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items",null); c.moveToFirst(); int n=c.getInt(0); c.close(); return n; }
    public int lowStock(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items WHERE quantity<=min_quantity",null); c.moveToFirst(); int n=c.getInt(0); c.close(); return n; }
    public double totalQuantity(){ Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(quantity),0) FROM items",null); c.moveToFirst(); double n=c.getDouble(0); c.close(); return n; }
    public JSONObject exportJson() throws JSONException {
        JSONObject root=new JSONObject(); root.put("app","G-Stock"); root.put("version",1);
        JSONArray arr=new JSONArray(); Cursor c=getReadableDatabase().rawQuery("SELECT name,category,quantity,min_quantity,unit,supplier FROM items ORDER BY id",null);
        while(c.moveToNext()){ JSONObject o=new JSONObject(); o.put("name",c.getString(0)); o.put("category",c.getString(1)); o.put("quantity",c.getDouble(2)); o.put("min_quantity",c.getDouble(3)); o.put("unit",c.getString(4)); o.put("supplier",c.getString(5)); arr.put(o); }
        c.close(); root.put("items",arr); return root;
    }
    public void importJson(JSONObject root) throws JSONException {
        JSONArray arr=root.getJSONArray("items"); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { for(int i=0;i<arr.length();i++){ JSONObject o=arr.getJSONObject(i); ContentValues v=new ContentValues();
            v.put("name",o.getString("name")); v.put("category",o.optString("category","")); v.put("quantity",o.optDouble("quantity",0)); v.put("min_quantity",o.optDouble("min_quantity",0)); v.put("unit",o.optString("unit","")); v.put("supplier",o.optString("supplier","")); db.insert("items",null,v);
        } db.setTransactionSuccessful(); } finally { db.endTransaction(); }
    }
}
